
from GPIOLibrary import GPIOProcessor
GP = GPIOProcessor()
GP.cleanup()
