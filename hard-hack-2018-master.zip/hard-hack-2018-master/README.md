# hard-hack-2018
Repo for everything we did in the hackathon.
