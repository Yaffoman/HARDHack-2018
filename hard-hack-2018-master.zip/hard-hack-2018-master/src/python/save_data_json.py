import json


count = {}

count['apples'] = 1
count['oranges'] = 2
count['bananas'] = 0
count['carrots'] = 2

with open('counts.json', 'w') as f:
    json.dump(count, f)